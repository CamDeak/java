/*
 * Project:         Labcdeak001
 * Class Name:      Java One
 * Author:          C. Deak
 * Date:            1/14/20
 * Description:     Lab one of Java programming class one, simple wage calculator
*/
package labcdeak001;

public class Labcdeak001 {

    public static void main(String[] args)
    {
       
       
        // Expressions
        double rate = 10;
        double hours = 40;
        double taxes = 0.2;
        double grossPay;
        double netPay;
       
        // Constant
        final double DEDUCTION_RATE = 0.2;
       
        // calculate the gross pay, taxes and net pay.
        grossPay = rate * hours;
        taxes = grossPay * DEDUCTION_RATE;
        netPay = grossPay - taxes;
       
       //display results
        System.out.format("%-7s%5.2f\n","Hours:", hours);
        System.out.format("%-15s$%7.2f\n","Rate:", rate);
        System.out.format("%-15s$%7.2f\n","Gross Pay:", grossPay);
        System.out.format("%-15s$%7.2f\n","Deductions:", taxes);
        System.out.format("%-15s$%7.2f\n","Net Pay:", netPay);
               
    }
   
}
